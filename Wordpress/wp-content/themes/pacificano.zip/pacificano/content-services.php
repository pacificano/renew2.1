<?php 

// Custom Fields
$about_us_body	= get_field('about_us_body');

?>

<!-- OUR SERVICES -->
<section id="our-services">

	<div class="container aboutDiv">
	
    	<div class="row">
    		
    		<div class="col-md-12">
    			
    			<h2>Our Services</h2>

				<p class="lead"><?php echo $about_us_body; ?></p>

    		</div>

    	</div>

    </div>
	
</section>